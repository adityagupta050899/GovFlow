from datetime import datetime
import json

class Store:
    def __init__(self):
        self.cases = {}  # in-memory demo store

    def create_case(self, case_id: str, json_payload: str, file):
        try:
            data = json.loads(json_payload)
        except Exception:
            data = {"raw": json_payload}
        self.cases[case_id] = {
            "raw": data,
            "uploads": [getattr(file, "filename", None)] if file else [],
            "status": "NEW",
            "step": "-",
            "updated_at": datetime.utcnow().isoformat(),
            "applicant": data.get("name","Unknown")
        }

    def get_case(self, case_id: str):
        return self.cases.get(case_id, {})

    def update_case(self, case_id: str, patch: dict):
        self.cases[case_id].update(patch)

    def set_decision(self, case_id: str, action: str):
        self.cases[case_id]["final_decision"] = action
        self.cases[case_id]["status"] = action.upper()
