from .base import AgentBase

class DecisionDrafterAgent(AgentBase):
    name = "decision_drafter"
    def run(self, store, case_id: str):
        case = store.get_case(case_id)
        missing = case.get("validation",{}).get("missing",[])
        all_pass = all(item.get("pass") for item in case.get("checklist",[]))
        if missing:
            rec = {"recommendation":"needs_info","rationale":f"Missing fields: {', '.join(missing)}","risks":[],"uncertainty":0.3}
        elif all_pass:
            rec = {"recommendation":"approve","rationale":"All required checks passed","risks":[],"uncertainty":0.2}
        else:
            rec = {"recommendation":"deny","rationale":"One or more policy checks failed","risks":["compliance"],"uncertainty":0.4}
        store.update_case(case_id, {"recommendation": rec})
        return store.get_case(case_id)
