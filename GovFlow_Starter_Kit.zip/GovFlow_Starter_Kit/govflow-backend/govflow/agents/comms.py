from .base import AgentBase

class CommsAgent(AgentBase):
    name = "comms"
    def run(self, store, case_id: str):
        case = store.get_case(case_id)
        decision = case.get("final_decision","PENDING")
        message = f"Your application is now {decision.upper()}. Thank you for applying."
        store.update_case(case_id, {"message": message})
        return store.get_case(case_id)
