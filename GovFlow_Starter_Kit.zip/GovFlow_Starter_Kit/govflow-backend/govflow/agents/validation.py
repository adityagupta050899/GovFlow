from .base import AgentBase

class ValidationAgent(AgentBase):
    name = "validation"
    def run(self, store, case_id: str):
        case = store.get_case(case_id)
        nc = case.get("normalized_case",{})
        required = ["applicant", "email", "address", "business_type"]
        missing = [k for k in required if not nc.get(k)]
        validation = {
            "missing": missing,
            "docs_present": len(nc.get("docs",[])) > 0,
            "business_registry_ok": True  # mock
        }
        store.update_case(case_id, {"validation": validation, "status": "VALIDATED" if not missing else "INCOMPLETE"})
        return store.get_case(case_id)
