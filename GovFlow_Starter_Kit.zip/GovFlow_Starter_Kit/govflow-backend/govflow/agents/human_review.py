from .base import AgentBase

class HumanReviewAgent(AgentBase):
    name = "human_review"
    def run(self, store, case_id: str):
        case = store.get_case(case_id)
        rec = case.get("recommendation",{}).get("recommendation")
        if rec == "approve":
            store.set_decision(case_id, "approve")
        return store.get_case(case_id)
