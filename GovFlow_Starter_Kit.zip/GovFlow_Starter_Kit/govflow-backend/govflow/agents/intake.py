from .base import AgentBase

class IntakeAgent(AgentBase):
    name = "intake"
    def run(self, store, case_id: str):
        case = store.get_case(case_id)
        raw = case.get("raw", {})
        normalized = {
            "applicant": raw.get("name"),
            "email": raw.get("email"),
            "address": raw.get("address"),
            "business_type": raw.get("businessType"),
            "docs": case.get("uploads", [])
        }
        store.update_case(case_id, {"normalized_case": normalized, "status": "RECEIVED"})
        return store.get_case(case_id)
