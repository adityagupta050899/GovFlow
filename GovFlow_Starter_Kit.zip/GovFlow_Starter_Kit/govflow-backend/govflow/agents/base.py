class AgentBase:
    name = "base"
    def run(self, store, case_id: str):
        raise NotImplementedError
