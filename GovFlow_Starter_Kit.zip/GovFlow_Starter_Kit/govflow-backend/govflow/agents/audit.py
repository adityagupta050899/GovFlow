from .base import AgentBase

class AuditAgent(AgentBase):
    name = "audit"
    def run(self, store, case_id: str):
        audit = {"case_id": case_id, "events": ["intake","validation","policy_reasoner","decision_drafter","human_review","comms"]}
        store.update_case(case_id, {"audit": audit})
        return store.get_case(case_id)
