from .base import AgentBase

class PolicyReasonerAgent(AgentBase):
    name = "policy_reasoner"
    def run(self, store, case_id: str):
        case = store.get_case(case_id)
        nc = case.get("normalized_case",{})
        checklist = [
            {"rule_id":"R-1","requirement":"Valid address in jurisdiction","pass": bool(nc.get("address")),"confidence":0.9,"citation":"policy.pdf#p1"},
            {"rule_id":"R-2","requirement":"Business type allowed for sidewalk permit","pass": True,"confidence":0.8,"citation":"policy.pdf#p2"},
            {"rule_id":"R-3","requirement":"Uploaded required document(s)","pass": len(nc.get("docs",[]))>0,"confidence":0.85,"citation":"policy.pdf#p3"}
        ]
        store.update_case(case_id, {"checklist": checklist})
        return store.get_case(case_id)
