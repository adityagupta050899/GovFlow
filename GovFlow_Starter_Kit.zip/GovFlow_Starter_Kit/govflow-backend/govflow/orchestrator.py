from datetime import datetime
from .agents.intake import IntakeAgent
from .agents.validation import ValidationAgent
from .agents.policy_reasoner import PolicyReasonerAgent
from .agents.decision_drafter import DecisionDrafterAgent
from .agents.human_review import HumanReviewAgent
from .agents.comms import CommsAgent
from .agents.audit import AuditAgent

def orchestrate_case(store, case_id: str):
    store.update_case(case_id, {"status": "RECEIVED", "step": "intake", "updated_at": datetime.utcnow().isoformat()})
    IntakeAgent().run(store, case_id)

    store.update_case(case_id, {"step": "validation"})
    ValidationAgent().run(store, case_id)

    store.update_case(case_id, {"step": "policy_reason"})
    PolicyReasonerAgent().run(store, case_id)

    store.update_case(case_id, {"step": "decision_draft"})
    DecisionDrafterAgent().run(store, case_id)

    store.update_case(case_id, {"step": "human_review"})
    HumanReviewAgent().run(store, case_id)

    store.update_case(case_id, {"step": "comms"})
    CommsAgent().run(store, case_id)

    store.update_case(case_id, {"step": "audit"})
    AuditAgent().run(store, case_id)

    store.update_case(case_id, {"status": "COMPLETED", "updated_at": datetime.utcnow().isoformat()})
