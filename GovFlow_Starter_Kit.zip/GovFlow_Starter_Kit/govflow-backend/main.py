from fastapi import FastAPI, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import uuid

from govflow.orchestrator import orchestrate_case
from govflow.store import Store

app = FastAPI(title="GovFlow Backend")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

store = Store()

class CaseStatus(BaseModel):
    case_id: str
    status: str
    step: str
    updated_at: str

@app.post("/cases/submit")
async def submit_case(json: str = Form(...), file: Optional[UploadFile] = None):
    case_id = str(uuid.uuid4())[:8]
    store.create_case(case_id, json, file)
    orchestrate_case(store, case_id)  # synchronous for demo simplicity
    return {"case_id": case_id}

@app.get("/cases/status")
def case_status(case_id: str):
    case = store.get_case(case_id)
    return CaseStatus(
        case_id=case_id,
        status=case.get("status","UNKNOWN"),
        step=case.get("step","-"),
        updated_at=case.get("updated_at", datetime.utcnow().isoformat())
    )

@app.get("/cases/list")
def list_cases():
    items = [{"case_id": k, "applicant": v.get("applicant","Unknown"), "status": v.get("status","-")} for k,v in store.cases.items()]
    return {"cases": items}

@app.get("/cases/detail")
def case_detail(case_id: str):
    case = store.get_case(case_id)
    payload = {
        "case_id": case_id,
        "case": case.get("normalized_case",{}),
        "checklist": case.get("checklist",[]),
        "recommendation": case.get("recommendation",{})
    }
    return payload

class Action(BaseModel):
    case_id: str
    action: str  # approve | deny | request_info

@app.post("/cases/action")
def case_action(a: Action):
    store.set_decision(a.case_id, a.action)
    return {"ok": True}
