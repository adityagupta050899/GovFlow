"use client";
import { useState } from "react";
import axios from "axios";

export default function Apply() {
  const [form, setForm] = useState({ name: "", email: "", address: "", businessType: "" });
  const [file, setFile] = useState<File | null>(null);
  const [submitted, setSubmitted] = useState<string | null>(null);

  const submit = async () => {
    const data = new FormData();
    data.append("json", JSON.stringify(form));
    if (file) data.append("file", file);
    const base = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";
    const res = await axios.post(base + "/cases/submit", data, { headers: { "Content-Type": "multipart/form-data" } });
    setSubmitted(res.data.case_id);
  };

  return (
    <main className="p-8 max-w-2xl mx-auto">
      <h2 className="text-2xl font-semibold mb-4">Small-Business Sidewalk Permit</h2>
      <div className="grid gap-3">
        <input className="border p-2" placeholder="Full Name" value={form.name} onChange={e=>setForm({...form, name: e.target.value})}/>
        <input className="border p-2" placeholder="Email" value={form.email} onChange={e=>setForm({...form, email: e.target.value})}/>
        <input className="border p-2" placeholder="Address" value={form.address} onChange={e=>setForm({...form, address: e.target.value})}/>
        <input className="border p-2" placeholder="Business Type" value={form.businessType} onChange={e=>setForm({...form, businessType: e.target.value})}/>
        <input className="border p-2" type="file" onChange={e=>setFile(e.target.files?.[0] ?? null)}/>
        <button className="border px-4 py-2" onClick={submit}>Submit</button>
      </div>
      {submitted && <p className="mt-4">Submitted! Your Case ID: <b>{submitted}</b></p>}
    </main>
  );
}
