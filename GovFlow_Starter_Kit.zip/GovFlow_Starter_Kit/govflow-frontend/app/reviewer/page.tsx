"use client";
import { useEffect, useState } from "react";
import axios from "axios";

type CaseLite = { case_id: string, applicant: string, status: string };

export default function Reviewer() {
  const [cases, setCases] = useState<CaseLite[]>([]);
  const [selected, setSelected] = useState<any>(null);

  const base = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";

  useEffect(()=>{
    (async()=>{
      const res = await axios.get(base + "/cases/list");
      setCases(res.data.cases);
    })();
  },[]);

  const openCase = async (id: string) => {
    const res = await axios.get(base + "/cases/detail", { params: { case_id: id }});
    setSelected(res.data);
  };

  const action = async (verb: "approve" | "deny" | "request_info") => {
    await axios.post(base + "/cases/action", { case_id: selected.case_id, action: verb });
    const res = await axios.get(base + "/cases/detail", { params: { case_id: selected.case_id }});
    setSelected(res.data);
  };

  return (
    <main className="p-8 grid md:grid-cols-3 gap-6">
      <section className="md:col-span-1">
        <h2 className="text-xl font-semibold mb-2">Queue</h2>
        <div className="space-y-2">
          {cases.map(c => (
            <button key={c.case_id} className="w-full text-left border p-2 rounded"
              onClick={()=>openCase(c.case_id)}>
              <div className="flex justify-between">
                <span>{c.case_id}</span>
                <span className="opacity-70">{c.status}</span>
              </div>
              <div className="text-sm opacity-80">{c.applicant}</div>
            </button>
          ))}
        </div>
      </section>
      <section className="md:col-span-2">
        <h2 className="text-xl font-semibold mb-2">Reviewer Console</h2>
        {!selected && <p>Select a case from the queue.</p>}
        {selected && (
          <div className="grid gap-4">
            <div className="border p-3 rounded">
              <h3 className="font-semibold mb-1">Case</h3>
              <pre className="text-sm overflow-auto">{JSON.stringify(selected.case, null, 2)}</pre>
            </div>
            <div className="border p-3 rounded">
              <h3 className="font-semibold mb-1">Checklist (with citations)</h3>
              <pre className="text-sm overflow-auto">{JSON.stringify(selected.checklist, null, 2)}</pre>
            </div>
            <div className="border p-3 rounded">
              <h3 className="font-semibold mb-1">AI Recommendation</h3>
              <pre className="text-sm overflow-auto">{JSON.stringify(selected.recommendation, null, 2)}</pre>
            </div>
            <div className="flex gap-2">
              <button className="border px-3 py-2 rounded" onClick={()=>action("approve")}>Approve</button>
              <button className="border px-3 py-2 rounded" onClick={()=>action("request_info")}>Request Info</button>
              <button className="border px-3 py-2 rounded" onClick={()=>action("deny")}>Deny</button>
            </div>
          </div>
        )}
      </section>
    </main>
  );
}
