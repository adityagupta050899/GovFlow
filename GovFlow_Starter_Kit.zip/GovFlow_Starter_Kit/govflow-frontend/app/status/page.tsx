"use client";
import { useState } from "react";
import axios from "axios";

export default function Status() {
  const [caseId, setCaseId] = useState<string>("");
  const [status, setStatus] = useState<any>(null);

  const fetchStatus = async () => {
    const base = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8000";
    const res = await axios.get(base + "/cases/status", { params: { case_id: caseId } });
    setStatus(res.data);
  };

  return (
    <main className="p-8 max-w-2xl mx-auto">
      <h2 className="text-2xl font-semibold mb-4">Check Case Status</h2>
      <div className="flex gap-2 mb-4">
        <input className="border p-2 flex-1" placeholder="Enter Case ID" value={caseId} onChange={e=>setCaseId(e.target.value)}/>
        <button className="border px-4" onClick={fetchStatus}>Fetch</button>
      </div>
      {status && (
        <div className="border p-4 rounded">
          <p><b>Case:</b> {status.case_id}</p>
          <p><b>Status:</b> {status.status}</p>
          <p><b>Step:</b> {status.step}</p>
          <p><b>Updated:</b> {status.updated_at}</p>
        </div>
      )}
    </main>
  );
}
