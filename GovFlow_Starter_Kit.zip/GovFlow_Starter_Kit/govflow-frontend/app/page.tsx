"use client";
import Link from "next/link";

export default function Home() {
  return (
    <main className="p-8 max-w-3xl mx-auto">
      <h1 className="text-3xl font-semibold mb-4">GovFlow Agent</h1>
      <p className="mb-6">Automate public-service requests with human-in-the-loop transparency.</p>
      <div className="grid gap-4">
        <Link className="underline" href="/apply">Start a Permit Application →</Link>
        <Link className="underline" href="/status">Check Status →</Link>
        <Link className="underline" href="/reviewer">Reviewer Console →</Link>
      </div>
    </main>
  );
}
