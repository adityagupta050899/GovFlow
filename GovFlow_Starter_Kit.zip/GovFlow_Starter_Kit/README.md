# GovFlow Agent — Starter Kit

This bundle provides:
- **GovFlow_Sprint_Board.csv** — Notion-ready tasks
- **govflow-frontend/** — Next.js (TypeScript) UI for Citizen + Reviewer
- **govflow-backend/** — FastAPI agent pipeline (ADK-style stubs)

## Quick Start

### Backend
```bash
cd govflow-backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
./run.sh
```

### Frontend
```bash
cd govflow-frontend
cp .env.local.example .env.local
npm install
npm run dev
```
Open http://localhost:3000

## Replace Mocks with Google ADK + Gemini
- Wire RAG + structured outputs in `govflow/agents/policy_reasoner.py`
- Swap orchestrator to Google ADK graph in `govflow/orchestrator.py`
