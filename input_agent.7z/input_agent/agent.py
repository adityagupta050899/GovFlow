import datetime
from google.adk.agents import Agent

# -----------------------------
# Tools (simple, deterministic)
# -----------------------------

def make_move_plan(
    entity_type: str,
    dc_address: str,
    has_employees: bool,
    lease_start: str,
) -> dict:
    """Builds a tiny, 5-step plan for moving a VA business to DC.

    Args:
        entity_type (str): "LLC" or "Corporation".
        dc_address (str): DC business address.
        has_employees (bool): Whether the business has employees.
        lease_start (str): ISO date "YYYY-MM-DD".

    Returns:
        dict: status and report (or error_message).
    """
    if not (entity_type and dc_address and lease_start):
        return {"status": "error", "error_message": "Missing required inputs."}

    try:
        dt = datetime.date.fromisoformat(lease_start)
    except ValueError:
        return {"status": "error", "error_message": "lease_start must be YYYY-MM-DD."}

    steps = [
        "Register DC taxes (FR-500)",
        "File DC foreign registration",
        "Apply for DC Basic Business License (BBL)",
        "Cut over payroll/sales to DC on lease start date",
        "Off-board Arlington/VA accounts",
    ]
    report = (
        f"Plan for moving your {entity_type} to DC at {dc_address}.\n"
        f"Recommended path: Keep VA entity; register to operate in DC (foreign registration).\n"
        f"Lease start: {dt.isoformat()} | Employees: {'Yes' if has_employees else 'No'}\n"
        f"Milestones: {', '.join(steps)}"
    )
    return {"status": "success", "report": report, "steps": steps}


def dc_tax_register(ein: str, responsible_person: str, email: str) -> dict:
    """Mocks DC tax registration (sales/use, withholding, franchise)."""
    if not (ein and ein.isdigit() and len(ein) == 9):
        return {"status": "error", "error_message": "EIN must be 9 digits."}
    if not responsible_person or "@" not in email:
        return {"status": "error", "error_message": "Missing responsible_person or valid email."}

    confirmation = "FR-500-A12K"
    return {
        "status": "success",
        "report": (
            "DC tax registration submitted (Sales/Use, Withholding, Franchise). "
            f"Confirmation #: {confirmation}. Status: Pending → Active (demo)."
        ),
        "confirmation": confirmation,
    }


def dc_file_foreign_registration(va_entity_name: str, dc_address: str) -> dict:
    """Mocks filing a foreign registration for the VA entity in DC."""
    if not va_entity_name or not dc_address:
        return {"status": "error", "error_message": "va_entity_name and dc_address are required."}

    tracking = "DC-FR-1842"
    return {
        "status": "success",
        "report": (
            f"Foreign registration filed for '{va_entity_name}' at '{dc_address}'. "
            f"Tracking #: {tracking}. Status: Filed → Approved (demo)."
        ),
        "tracking_number": tracking,
    }


def dc_apply_bbl(endorsement: str = "General Business", lease_uploaded: bool = True) -> dict:
    """Mocks applying for a DC Basic Business License (BBL)."""
    if not lease_uploaded:
        return {"status": "error", "error_message": "Lease document required for BBL (demo rule)."}

    app_no = "BBL-G-9074"
    return {
        "status": "success",
        "report": (
            f"BBL application submitted (endorsement: {endorsement}). "
            f"Application #: {app_no}. Status: Submitted → Under review → Active (demo)."
        ),
        "application_number": app_no,
    }


def schedule_dc_cutover(lease_start: str) -> dict:
    """Creates a tiny cutover checklist keyed to the lease start date."""
    try:
        d = datetime.date.fromisoformat(lease_start)
    except ValueError:
        return {"status": "error", "error_message": "lease_start must be YYYY-MM-DD."}

    checklist = [
        f"{d.isoformat()}: Begin collecting DC sales tax",
        f"{d.isoformat()}: Switch payroll to DC withholding",
        f"{d.isoformat()}: Use DC address on invoices/contracts",
    ]
    return {"status": "success", "report": "Cutover scheduled.", "checklist": checklist}


def offboard_arlington_va(final_va_sale_date: str = "", final_va_payroll_date: str = "") -> dict:
    """Mocks off-boarding steps for Arlington/VA."""
    actions = [
        "Cancel Arlington BPOL",
        "Close VA Dept. of Taxation sales/withholding accounts",
        "Close VA unemployment (if no payroll in VA)",
    ]
    meta = []
    if final_va_sale_date:
        meta.append(f"Final VA sale: {final_va_sale_date}")
    if final_va_payroll_date:
        meta.append(f"Final VA payroll: {final_va_payroll_date}")

    tail = f" ({'; '.join(meta)})" if meta else ""
    return {"status": "success", "report": "Off-boarding scheduled: " + ", ".join(actions) + tail, "actions": actions}


def get_demo_status() -> dict:
    """Returns a compact status snapshot for UI tickers/badges."""
    state = {
        "plan": "done",
        "dc_taxes": "active",
        "foreign_reg": "approved",
        "bbl": "active",
        "cutover": "scheduled",
        "offboard_va": "scheduled",
        "receipts": {
            "dc_tax_conf": "FR-500-A12K",
            "foreign_reg_track": "DC-FR-1842",
            "bbl_app": "BBL-G-9074",
            "clean_hands": "clear",
        },
    }
    bar = "[■■■■□□□□] 3/6  Plan ▸ DC Taxes ▸ Foreign Reg ▸ BBL ▸ Cutover ▸ Off-board"
    return {"status": "success", "report": bar, "state": state}


# -----------------------------
# ADK Agent
# -----------------------------

root_agent = Agent(
    name="arlington_to_dc_agent",
    model="gemini-2.0-flash",
    description="Demo agent that helps move a small business from Arlington, VA to Washington, DC.",
    instruction=(
        "You are a concise move-manager. Use the tools to: "
        "1) make a plan, 2) register DC taxes, 3) file foreign registration, "
        "4) apply for a BBL, 5) schedule cutover, 6) off-board Arlington/VA. "
        "Return short status updates and include confirmation numbers when available."
    ),
    tools=[
        make_move_plan,
        dc_tax_register,
        dc_file_foreign_registration,
        dc_apply_bbl,
        schedule_dc_cutover,
        offboard_arlington_va,
        get_demo_status,
    ],
)
